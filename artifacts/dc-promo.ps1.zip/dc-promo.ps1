configuration AD
{
    param
    (
        [Parameter(Mandatory)][PSCredential]$DomainCred,
        [Parameter(Mandatory)][String]$DomainName
    )

    Import-DscResource -ModuleName ActiveDirectoryDsc
    Import-DscResource -ModuleName StorageDsc
    Import-DscResource -ModuleName DnsServerDsc
    Import-DscResource -ModuleName PSDesiredStateConfiguration

    node "localhost"
    {
        LocalConfigurationManager            
        {            
            ActionAfterReboot = 'ContinueConfiguration'
            ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
            AllowModuleOverwrite = $true
        }

        Disk DataDrive
        {
            DiskId = (get-disk | Where-Object {$_.PartitionStyle -eq "RAW"})[0].Number
            DriveLetter = 'F'
            FSFormat = 'NTFS'
            FSLabel = "AD Data"
        }

        WindowsFeature ADDSInstall
        { 
            Ensure = "Present" 
            Name = "AD-Domain-Services"
        }
        WindowsFeature ADDSTools            
        {             
            Ensure = "Present"             
            Name = "RSAT-ADDS"             
        }

        WaitForADDomain 'WaitForestAvailability'
        {
            DomainName = $DomainName
            Credential = $DomainCred

            DependsOn  = '[WindowsFeature]ADDSTools', '[WindowsFeature]ADDSInstall'
        }

        ADDomainController 'PromoteDC'
        {
            DomainName = $DomainName
            Credential = $DomainCred
            SafemodeAdministratorPassword = $DomainCred
            DatabasePath = 'F:\Windows\NTDS'
            LogPath = 'F:\Windows\NTDS'
            SysvolPath = 'F:\Windows\SYSVOL'
		IsGlobalCatalog = $true

            DependsOn = '[WaitForADDomain]WaitForestAvailability','[Disk]DataDrive'
        }

        DnsServerForwarder 'SetAzureForwarder'
	  {
		IPAddresses = @('168.63.129.16')
		UseRootHint = $false
		IsSingleInstance = 'Yes'

		DependsOn = '[DnsServerForwarder]SetAzureForwarder'
	  }
    }
}