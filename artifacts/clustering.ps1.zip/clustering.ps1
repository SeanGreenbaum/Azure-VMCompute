configuration clusternode
{
    Import-DscResource -ModuleName PSDesiredStateConfiguration
   
    node "localhost"
    {
        LocalConfigurationManager            
        {            
            ActionAfterReboot = 'ContinueConfiguration'
            ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
            AllowModuleOverwrite = $true
        }

        WindowsFeature Clustering
        { 
            Ensure = "Present" 
            Name = "Failover-Clustering"
        }
        WindowsFeature RSAT-Clustering
        {             
            Ensure = "Present"             
            Name = "RSAT-Clustering"             
        }

        WindowsFeature RSAT-Clustering-AutomationServer
        {             
            Ensure = "Present"             
            Name = "RSAT-Clustering-AutomationServer"             
        }

        WindowsFeature RSAT-Clustering-CmdInterface
        {             
            Ensure = "Present"             
            Name = "RSAT-Clustering-CmdInterface"             
        }
    }
}