configuration clusternode
{
    Import-DscResource -ModuleName PSDesiredStateConfiguration
   
    node "localhost"
    {
        LocalConfigurationManager            
        {            
            ActionAfterReboot = 'ContinueConfiguration'
            ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
            AllowModuleOverwrite = $true
        }

        WindowsFeature Clustering
        { 
            Ensure = "Present" 
            Name = "Failover-Clustering"
        }
        WindowsFeature RSAT-Clustering
        {             
            Ensure = "Present"             
            Name = "RSAT-Clustering"             
        }

        WindowsFeature RSAT-Mgmt
        {             
            Ensure = "Present"             
            Name = "RSAT-Mgmt"             
        }

        WindowsFeature RSAT-PowerShell
        {             
            Ensure = "Present"             
            Name = "RSAT-PowerShell"             
        }

        WindowsFeature RSAT-AutomationServer
        {             
            Ensure = "Present"             
            Name = "RSAT-AutomationServer"             
        }

        WindowsFeature RSAT-CmdInterface
        {             
            Ensure = "Present"             
            Name = "RSAT-CmdInterface"             
        }
    }
}