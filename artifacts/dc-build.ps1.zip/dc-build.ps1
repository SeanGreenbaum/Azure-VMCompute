configuration AD
{
    param
    (
        [Parameter(Mandatory)][PSCredential]$DomainCred,
        [Parameter(Mandatory)][String]$DomainName,
        [Parameter(Mandatory)][String]$DomainNetBIOSName,
        [Parameter(Mandatory)][String]$DomainDN,
        [Parameter(Mandatory)][String]$CompanyName
    )

    Import-DscResource -ModuleName ActiveDirectoryDsc
    Import-DscResource -ModuleName StorageDsc
    #Import-DscResource -ModuleName xPSDesiredStateConfiguration
    
    node "localhost"
    {
        LocalConfigurationManager            
        {            
            ActionAfterReboot = 'ContinueConfiguration'
            ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
            AllowModuleOverwrite = $true
        }

        Disk DataDrive
        {
            DiskId = (get-disk | Where-Object {$_.PartitionStyle -eq "RAW"})[0].Number
            DriveLetter = 'F'
            FSFormat = 'NTFS'
            FSLabel = "AD Data"
        }

        WindowsFeature ADDSInstall
        { 
            Ensure = "Present" 
            Name = "AD-Domain-Services"
        }
        WindowsFeature ADDSTools            
        {             
            Ensure = "Present"             
            Name = "RSAT-ADDS"             
        }

        ADDomain ADConfiguration
        {
            DomainName = $DomainName
            DomainNetbiosName = $DomainNetBIOSName
            Credential = $DomainCred
            SafemodeAdministratorPassword = $DomainCred
            DatabasePath = 'F:\NTDS'
            LogPath = 'F:\NTDS'
            SysvolPath = 'F:\SYSVOL'
            DependsOn = "[WindowsFeature]ADDSInstall",'[Disk]DataDrive'
        }
        ADOrganizationalUnit ADOURoot
        {
            Name = $CompanyName
            Path = $DomainDN
            ProtectedFromAccidentalDeletion = $false
            Credential = $DomainCred
            DependsOn = '[ADDomain]ADConfiguration'
        }
        ADOrganizationalUnit ADOUPeople
        {
            Name = 'People'
            Path = "OU=$CompanyName,$DomainDN"
            ProtectedFromAccidentalDeletion = $false
            Credential = $DomainCred
            DependsOn = '[ADOrganizationalUnit]ADOURoot'
        }
        ADOrganizationalUnit ADOUGroups
        {
            Name = 'Groups'
            Path = "OU=$CompanyName,$DomainDN"
            ProtectedFromAccidentalDeletion = $false
            Credential = $DomainCred
            DependsOn = '[ADOrganizationalUnit]ADOURoot'
        }
        ADOrganizationalUnit ADOUServiceAccounts
        {
            Name = 'Service Accounts'
            Path = "OU=$CompanyName,$DomainDN"
            ProtectedFromAccidentalDeletion = $false
            Credential = $DomainCred
            DependsOn = '[ADOrganizationalUnit]ADOURoot'
        }
        ADOrganizationalUnit ADOUWorkstations
        {
            Name = 'Workstations'
            Path = "OU=$CompanyName,$DomainDN"
            ProtectedFromAccidentalDeletion = $false
            Credential = $DomainCred
            DependsOn = '[ADOrganizationalUnit]ADOURoot'
        }
        ADOrganizationalUnit ADOUServers
        {
            Name = 'Servers'
            Path = "OU=$CompanyName,$DomainDN"
            ProtectedFromAccidentalDeletion = $false
            Credential = $DomainCred
            DependsOn = '[ADOrganizationalUnit]ADOURoot'
        }
        ADOrganizationalUnit ADOUAdminRoot
        {
            Name = 'Admin'
            Path = $DomainDN
            ProtectedFromAccidentalDeletion = $false
            Credential = $DomainCred
            DependsOn = '[ADDomain]ADConfiguration'
        }
        ADOrganizationalUnit ADOUTier0
        {
            Name = 'Tier 0'
            Path = "OU=Admin,$DomainDN"
            ProtectedFromAccidentalDeletion = $false
            Credential = $DomainCred
            DependsOn = '[ADOrganizationalUnit]ADOUAdminRoot'
        }
        ADOrganizationalUnit ADOUTier1
        {
            Name = 'Tier 1'
            Path = "OU=Admin,$DomainDN"
            ProtectedFromAccidentalDeletion = $false
            Credential = $DomainCred
            DependsOn = '[ADOrganizationalUnit]ADOUAdminRoot'
        }
        ADOrganizationalUnit ADOUTier2
        {
            Name = 'Tier 2'
            Path = "OU=Admin,$DomainDN"
            ProtectedFromAccidentalDeletion = $false
            Credential = $DomainCred
            DependsOn = '[ADOrganizationalUnit]ADOUAdminRoot'
        }
    }
}