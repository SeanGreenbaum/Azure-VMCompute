configuration AD
{
    param
    (
        [Parameter(Mandatory)][PSCredential]$DomainCred,
        [Parameter(Mandatory)][String]$DomainName,
        [Parameter(Mandatory)][String]$DomainNetBIOSName,
        [Parameter(Mandatory)][String]$DomainDN,
        [Parameter(Mandatory)][String]$CompanyName
    )

    Import-DscResource -ModuleName ActiveDirectoryDsc
    Import-DscResource -ModuleName StorageDsc
    Import-DscResource -ModuleName PSDesiredStateConfiguration

    $ipConfig = (Get-NetAdapter -Physical | Get-NetIPConfiguration | Where-Object IPv4DefaultGateway)
    Set-DnsClientServerAddress -InterfaceIndex $ipConfig.InterfaceIndex -ServerAddresses $ipConfig.IPv4Address.IPAddress
    
    node "localhost"
    {
        LocalConfigurationManager            
        {            
            ActionAfterReboot = 'ContinueConfiguration'
            ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
            AllowModuleOverwrite = $true
        }

        Disk DataDrive
        {
            DiskId = (get-disk | Where-Object {$_.PartitionStyle -eq "RAW"})[0].Number
            DriveLetter = 'F'
            FSFormat = 'NTFS'
            FSLabel = "AD Data"
        }

        WindowsFeature ADDSInstall
        { 
            Ensure = "Present" 
            Name = "AD-Domain-Services"
        }
        WindowsFeature ADDSTools            
        {             
            Ensure = "Present"             
            Name = "RSAT-ADDS"             
        }

        ADDomain ADConfiguration
        {
            DomainName = $DomainName
            DomainNetbiosName = $DomainNetBIOSName
            Credential = $DomainCred
            SafemodeAdministratorPassword = $DomainCred
            DatabasePath = 'F:\Windows\NTDS'
            LogPath = 'F:\Windows\NTDS'
            SysvolPath = 'F:\Windows\SYSVOL'
            DependsOn = "[WindowsFeature]ADDSInstall",'[Disk]DataDrive'
        }

        Script SetDNSForwarderToAzure {
            SetScript  = {
                Set-DnsServerForwarder -IPAddress 168.63.129.16
            }
            TestScript = {
                (Get-DnsServerForwarder).IPAddress.IPAddressToString -eq '168.63.129.16'
            }
            GetScript  = {
                @{Ensure = if ((Get-DnsServerForwarder).IPAddress.IPAddressToString -eq '168.63.129.16') { 'Present' } Else { 'Absent' } }
            }
            DependsOn  = '[ADDomain]ADConfiguration'


        WaitForADDomain 'WaitForestAvailability'
        {
            DomainName = $DomainName
            Credential = $DomainCred
            DependsOn  = '[WindowsFeature]ADDSTools','[ADDomain]ADConfiguration'
        }

        ADOrganizationalUnit ADOURoot
        {
            Name = $CompanyName
            Path = $DomainDN
            ProtectedFromAccidentalDeletion = $false
            Credential = $DomainCred
            DependsOn = '[ADDomain]ADConfiguration','[WaitForADDomain]WaitForestAvailability'
        }
        ADOrganizationalUnit ADOUPeople
        {
            Name = 'People'
            Path = "OU=$CompanyName,$DomainDN"
            ProtectedFromAccidentalDeletion = $false
            Credential = $DomainCred
            DependsOn = '[ADOrganizationalUnit]ADOURoot'
        }
        ADOrganizationalUnit ADOUGroups
        {
            Name = 'Groups'
            Path = "OU=$CompanyName,$DomainDN"
            ProtectedFromAccidentalDeletion = $false
            Credential = $DomainCred
            DependsOn = '[ADOrganizationalUnit]ADOURoot'
        }
        ADOrganizationalUnit ADOUServiceAccounts
        {
            Name = 'Service Accounts'
            Path = "OU=$CompanyName,$DomainDN"
            ProtectedFromAccidentalDeletion = $false
            Credential = $DomainCred
            DependsOn = '[ADOrganizationalUnit]ADOURoot'
        }
        ADOrganizationalUnit ADOUWorkstations
        {
            Name = 'Workstations'
            Path = "OU=$CompanyName,$DomainDN"
            ProtectedFromAccidentalDeletion = $false
            Credential = $DomainCred
            DependsOn = '[ADOrganizationalUnit]ADOURoot'
        }
        ADOrganizationalUnit ADOUServers
        {
            Name = 'Servers'
            Path = "OU=$CompanyName,$DomainDN"
            ProtectedFromAccidentalDeletion = $false
            Credential = $DomainCred
            DependsOn = '[ADOrganizationalUnit]ADOURoot'
        }
        ADOrganizationalUnit ADOUAdminRoot
        {
            Name = 'Admin'
            Path = $DomainDN
            ProtectedFromAccidentalDeletion = $false
            Credential = $DomainCred
            DependsOn = '[ADDomain]ADConfiguration','[WaitForADDomain]WaitForestAvailability'
        }
        ADOrganizationalUnit ADOUTier0
        {
            Name = 'Tier 0'
            Path = "OU=Admin,$DomainDN"
            ProtectedFromAccidentalDeletion = $false
            Credential = $DomainCred
            DependsOn = '[ADOrganizationalUnit]ADOUAdminRoot'
        }
        ADOrganizationalUnit ADOUTier1
        {
            Name = 'Tier 1'
            Path = "OU=Admin,$DomainDN"
            ProtectedFromAccidentalDeletion = $false
            Credential = $DomainCred
            DependsOn = '[ADOrganizationalUnit]ADOUAdminRoot'
        }
        ADOrganizationalUnit ADOUTier2
        {
            Name = 'Tier 2'
            Path = "OU=Admin,$DomainDN"
            ProtectedFromAccidentalDeletion = $false
            Credential = $DomainCred
            DependsOn = '[ADOrganizationalUnit]ADOUAdminRoot'
        }
    }
}